package productosdebelleza;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Random;
import java.util.Scanner;

public class ProductosDeBelleza {

    public static void main(String[] args) {
        
        
        System.out.print("prueba de articulo");
      Articulo art = new Articulo(11111, Articulo.Nombres.ceraEgo );
      
        System.out.println("el nombre del articulo es: "+ art.getNombre());
        System.out.println("el precio del articulo es: "+art.getPrecio());
        System.out.println("la identificacion del articulo es: "+ art.getId());
        System.out.println("el tipo de producto es: " + art.getProducto());
        
        /*
        prueba de articulo
        */
        int art_total = 1000000;
        Random aleatorio = new Random();
      	LinkedList<Articulo> camion = new LinkedList<>();
       
        for(int i = 1; i <= art_total; i++ ){
            
            int id_random = aleatorio.nextInt(art_total);
            
            Articulo.Nombres[] nombres = Articulo.Nombres.values();
            Articulo.Nombres nombre_random = nombres[aleatorio.nextInt(15)];
            
            
            Articulo articulo = new Articulo(id_random, nombre_random);
            camion.add(articulo);
        }
        
        System.out.println("se han creado" + camion.size() + "articulos" );
        /*
        for(Articulo i: camion){
            System.out.print(i.getId());
            System.out.print(i.getNombre());
            System.out.print(i.getProducto());
            System.out.print(i.getPrecio());
            System.out.println("------------");
        }
        */
        //prueba de articulos
        
        long capital_total = 0;
        
        for(Articulo i: camion){
            capital_total += i.getPrecio();
        }
                    
        
        System.out.println("-------------------------------------------");
        System.out.println("se tiene un capital de:   "+ capital_total);
        System.out.println("-------------------------------------------");
        System.out.println("-------------------------------------------");
        
        ArrayList<Articulo> cera_org = new ArrayList<>();
	ArrayList<Articulo> secador_org = new ArrayList<>();
	ArrayList<Articulo> plancha_org = new ArrayList<>();
	ArrayList<Articulo> crema_org = new ArrayList<>();
	ArrayList<Articulo> shampoo_org = new ArrayList<>();

        for (Articulo i : camion){
		switch(i.getProducto()){
			case cera:
                            cera_org.add(i);
                            break;
			case secador:
				secador_org.add(i);
				break;
			case plancha:
				plancha_org.add(i);
				break;
			case crema:
				crema_org.add(i);
				break;
			case shampoo:
				shampoo_org.add(i);
				break;
                    }
                }
        System.out.println("se han creado colas con de: ");
        System.out.println("cera con: "+cera_org.size()+" elementos");
        System.out.println("secador con: "+secador_org.size()+" elementos");
        System.out.println("plancha con: "+plancha_org.size()+" elementos");
        System.out.println("crema con: "+crema_org.size()+" elementos");
        System.out.println("shampoo con: "+shampoo_org.size()+" elementos");

        //menu----
        
        Scanner scan = new Scanner(System.in);
        
        int a = 1;
        do{
            
        }while(a != 2);
    }
    
}

package productosdebelleza;

public class Articulo {
    private int id;
    private int precio;
    private Nombres nombre;
    private Categoria producto;
    
    public enum Nombres
            {
                ceraEgo, ceraMonkey, ceraApolo, 
                secadorRevlon, secadorWolf, secadorBighair,
                planchaSolaris, planchaPool, planchaUltimus,
                cremaHidrofull, cremaPhill, cremaRoshe,
                shampooPantene, shampooNacho, shampooHys
            }
    public enum Categoria
            {
                cera, secador, plancha, crema, shampoo
            }
    public Articulo(){
        
    }
    

    public Articulo(int id, Nombres nombre) {
        this.id = id;
        this.nombre = nombre;
        this.precio = asignarPrecio(nombre);
        this.producto = asignarCategoria(nombre);
    }
    
    private int asignarPrecio(Nombres nombre){
        switch (nombre){
            case ceraEgo:
                return 1000;
            case ceraMonkey:
                return 2000;
            case ceraApolo:
                return 3000;
            case secadorRevlon:
                return 4000;
            case secadorWolf:
                return 5000;
            case secadorBighair:
                return 6000;
            case planchaSolaris:
                return 7000;
            case planchaPool:
                return 8000;
            case planchaUltimus:
                return 9000;
            case cremaHidrofull:
                return 10000;
            case cremaRoshe:
                return 11000;
            case cremaPhill:
                return 12000;
            case shampooPantene:
                return 13000;
            case shampooNacho:
                return 14000;
            case shampooHys:
                return 15000;
            
            }
        return 0;
         }
        
      
    

    private Categoria asignarCategoria(Nombres nombre){
        switch (nombre){
            case ceraEgo :
            case ceraMonkey:
            case ceraApolo:
                return Categoria.cera;
            case cremaHidrofull:
            case cremaPhill:
            case cremaRoshe:
                return Categoria.crema;
            case planchaSolaris:
            case planchaPool:
            case planchaUltimus:
                return Categoria.plancha;
            case  secadorRevlon:
            case secadorWolf:
            case secadorBighair:
               return Categoria.secador;
            case shampooPantene: 
            case shampooNacho:
            case shampooHys:
                return Categoria.shampoo;
        }
        return null;
    }

    public int getId() {
        return id;
    }

    public int getPrecio() {
        return precio;
    }

    public Nombres getNombre() {
        return nombre;
    }

    public Categoria getProducto() {
        return producto;
    }
    
        
    
    
    
}
